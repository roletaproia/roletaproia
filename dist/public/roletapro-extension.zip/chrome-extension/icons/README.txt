ÍCONES DA EXTENSÃO

Para usar a extensão, você precisa adicionar ícones PNG nos seguintes tamanhos:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)  
- icon128.png (128x128 pixels)

Você pode:
1. Criar os ícones usando o icon.svg como base
2. Ou usar qualquer ferramenta online para converter SVG para PNG
3. Ou usar este site: https://www.iloveimg.com/pt/redimensionar-imagem

Por enquanto, a extensão funcionará mesmo sem os ícones, mas eles aparecerão como placeholders.
